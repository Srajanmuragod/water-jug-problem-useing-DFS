import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  CartesianGrid,
} from "recharts";

type Move = "rock" | "paper" | "scissors";
const MOVES: Move[] = ["rock", "paper", "scissors"];
const EMOJI: Record<Move, string> = { rock: "✊", paper: "✋", scissors: "✌️" };
const BEATS: Record<Move, Move> = { rock: "scissors", paper: "rock", scissors: "paper" };
const COUNTER: Record<Move, Move> = { rock: "paper", paper: "scissors", scissors: "rock" };

type Round = { player: Move; ai: Move; predicted: Move; result: "win" | "lose" | "draw" };

type PersistentStats = {
  wins: number;
  losses: number;
  draws: number;
  currentStreak: number;
  bestStreak: number;
  totalRounds: number;
};

const STORAGE_KEY = "rps-scoreboard";

function loadStats(): PersistentStats {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* noop */ }
  return { wins: 0, losses: 0, draws: 0, currentStreak: 0, bestStreak: 0, totalRounds: 0 };
}

function saveStats(stats: PersistentStats) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
  } catch { /* noop */ }
}

export function RPSGame() {
  const [history, setHistory] = useState<Round[]>([]);
  const [score, setScore] = useState({ you: 0, ai: 0, draw: 0 });
  const [lastConfidence, setLastConfidence] = useState<number | null>(null);
  const [stats, setStats] = useState<PersistentStats>(loadStats);

  // Markov-chain prediction: P(next | last two moves)
  const transitions = useMemo(() => {
    const map = new Map<string, Record<Move, number>>();
    for (let i = 0; i < history.length - 1; i++) {
      const key =
        (history[i - 1]?.player ?? "_") + "|" + history[i].player;
      const next = history[i + 1].player;
      const entry = map.get(key) ?? { rock: 0, paper: 0, scissors: 0 };
      entry[next] += 1;
      map.set(key, entry);
    }
    return map;
  }, [history]);

  function predictNext(): { move: Move; confidence: number } {
    if (history.length < 2) {
      return { move: MOVES[Math.floor(Math.random() * 3)], confidence: 1 / 3 };
    }
    const key =
      (history[history.length - 2]?.player ?? "_") +
      "|" +
      history[history.length - 1].player;
    const entry = transitions.get(key);
    if (!entry) {
      // fallback: overall frequency
      const counts: Record<Move, number> = { rock: 0, paper: 0, scissors: 0 };
      history.forEach((r) => counts[r.player]++);
      const total = history.length;
      let best: Move = "rock";
      MOVES.forEach((m) => { if (counts[m] > counts[best]) best = m; });
      return { move: best, confidence: counts[best] / total };
    }
    const total = entry.rock + entry.paper + entry.scissors;
    let best: Move = "rock";
    MOVES.forEach((m) => { if (entry[m] > entry[best]) best = m; });
    return { move: best, confidence: entry[best] / total };
  }

  function play(player: Move) {
    const { move: predicted, confidence } = predictNext();
    const ai = COUNTER[predicted];
    const result: Round["result"] =
      player === ai ? "draw" : BEATS[player] === ai ? "lose" : "win";
    setHistory((h) => [...h, { player, ai, predicted, result }]);
    setScore((s) => ({
      you: s.you + (result === "win" ? 1 : 0),
      ai: s.ai + (result === "lose" ? 1 : 0),
      draw: s.draw + (result === "draw" ? 1 : 0),
    }));
    setLastConfidence(confidence);

    setStats((prev) => {
      const currentStreak = result === "win" ? prev.currentStreak + 1 : 0;
      const next: PersistentStats = {
        wins: prev.wins + (result === "win" ? 1 : 0),
        losses: prev.losses + (result === "lose" ? 1 : 0),
        draws: prev.draws + (result === "draw" ? 1 : 0),
        currentStreak,
        bestStreak: Math.max(prev.bestStreak, currentStreak),
        totalRounds: prev.totalRounds + 1,
      };
      saveStats(next);
      return next;
    });
  }

  function reset() {
    setHistory([]);
    setScore({ you: 0, ai: 0, draw: 0 });
    setLastConfidence(null);
  }

  function resetAll() {
    reset();
    const cleared: PersistentStats = { wins: 0, losses: 0, draws: 0, currentStreak: 0, bestStreak: 0, totalRounds: 0 };
    setStats(cleared);
    saveStats(cleared);
  }

  const last = history[history.length - 1];
  const total = score.you + score.ai + score.draw;
  const aiWinRate = total ? Math.round((score.ai / total) * 100) : 0;

  // Mind-reader accuracy over time: cumulative % of rounds where AI correctly
  // predicted the player's move (draws count as a correct read too).
  const accuracySeries = useMemo(() => {
    let correct = 0;
    return history.map((r, i) => {
      if (r.predicted === r.player) correct += 1;
      return {
        round: i + 1,
        accuracy: Math.round((correct / (i + 1)) * 100),
      };
    });
  }, [history]);
  const currentAccuracy = accuracySeries.length
    ? accuracySeries[accuracySeries.length - 1].accuracy
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      <div className="mx-auto max-w-3xl px-6 py-12">
        <header className="text-center mb-10">
          <h1 className="text-5xl font-bold tracking-tight bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Mind Reader
          </h1>
          <p className="mt-3 text-muted-foreground">
            An AI that learns your patterns. Can you stay unpredictable?
          </p>
        </header>

        <div className="grid grid-cols-3 gap-3 mb-8">
          <ScoreCard label="You" value={score.you} accent="primary" />
          <ScoreCard label="Draws" value={score.draw} />
          <ScoreCard label="AI" value={score.ai} accent="accent" />
        </div>

        <Card className="p-6 mb-8 bg-card/60 backdrop-blur border-border">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              All-Time Scoreboard
            </h2>
            <Button variant="ghost" size="sm" onClick={resetAll} disabled={stats.totalRounds === 0}>
              Clear History
            </Button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-sm">
            <div>
              <div className="text-muted-foreground">Wins</div>
              <div className="text-2xl font-semibold text-primary">{stats.wins}</div>
            </div>
            <div>
              <div className="text-muted-foreground">Losses</div>
              <div className="text-2xl font-semibold text-destructive">{stats.losses}</div>
            </div>
            <div>
              <div className="text-muted-foreground">Draws</div>
              <div className="text-2xl font-semibold">{stats.draws}</div>
            </div>
            <div>
              <div className="text-muted-foreground">Total Rounds</div>
              <div className="text-2xl font-semibold">{stats.totalRounds}</div>
            </div>
            <div>
              <div className="text-muted-foreground">Current Streak</div>
              <div className="text-2xl font-semibold text-primary">{stats.currentStreak}</div>
            </div>
            <div>
              <div className="text-muted-foreground">Best Streak</div>
              <div className="text-2xl font-semibold text-accent">{stats.bestStreak}</div>
            </div>
          </div>
        </Card>

        <Card className="p-8 mb-6 bg-card/60 backdrop-blur border-border">
          {last ? (
            <div className="text-center">
              <div className="flex items-center justify-center gap-8 text-6xl mb-4">
                <div>
                  <div>{EMOJI[last.player]}</div>
                  <div className="text-xs text-muted-foreground mt-2">YOU</div>
                </div>
                <div className="text-2xl text-muted-foreground">vs</div>
                <div>
                  <div>{EMOJI[last.ai]}</div>
                  <div className="text-xs text-muted-foreground mt-2">AI</div>
                </div>
              </div>
              <div
                className={`text-2xl font-bold ${
                  last.result === "win"
                    ? "text-primary"
                    : last.result === "lose"
                    ? "text-destructive"
                    : "text-muted-foreground"
                }`}
              >
                {last.result === "win" ? "You win!" : last.result === "lose" ? "AI wins!" : "Draw"}
              </div>
              <div className="mt-3 text-sm text-muted-foreground">
                AI predicted you'd play{" "}
                <span className="text-foreground font-medium">{last.predicted}</span>
                {lastConfidence !== null && (
                  <> · {Math.round(lastConfidence * 100)}% confidence</>
                )}
              </div>
            </div>
          ) : (
            <div className="text-center py-6 text-muted-foreground">
              Make a move to begin. The AI starts random and learns from every round.
            </div>
          )}
        </Card>

        <div className="grid grid-cols-3 gap-3 mb-8">
          {MOVES.map((m) => (
            <button
              key={m}
              onClick={() => play(m)}
              className="group rounded-xl border border-border bg-card/60 backdrop-blur p-6 hover:border-primary hover:bg-card transition-all hover:-translate-y-1"
            >
              <div className="text-5xl group-hover:scale-110 transition-transform">{EMOJI[m]}</div>
              <div className="mt-2 text-sm uppercase tracking-wider text-muted-foreground capitalize">{m}</div>
            </button>
          ))}
        </div>

        <Card className="p-5 bg-card/40 backdrop-blur border-border">
          <div className="flex items-baseline justify-between mb-3">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Mind Reader Accuracy
            </h2>
            <div className="text-2xl font-bold text-primary">{currentAccuracy}%</div>
          </div>
          <div className="h-48 -ml-2">
            {accuracySeries.length > 1 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={accuracySeries} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
                  <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} />
                  <XAxis
                    dataKey="round"
                    tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    domain={[0, 100]}
                    ticks={[0, 33, 50, 100]}
                    tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(v) => `${v}%`}
                    width={36}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: 8,
                      fontSize: 12,
                    }}
                    formatter={(v: number) => [`${v}%`, "Accuracy"]}
                    labelFormatter={(l) => `Round ${l}`}
                  />
                  <ReferenceLine y={33} stroke="var(--muted-foreground)" strokeDasharray="4 4" label={{ value: "Random 33%", fill: "var(--muted-foreground)", fontSize: 10, position: "insideTopRight" }} />
                  <Line
                    type="monotone"
                    dataKey="accuracy"
                    stroke="var(--primary)"
                    strokeWidth={2.5}
                    dot={false}
                    activeDot={{ r: 4 }}
                    isAnimationActive={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-sm text-muted-foreground">
                Play a few rounds to see how well the AI is reading you.
              </div>
            )}
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            % of rounds where the AI correctly predicted your move. Above 33% means it's beating random.
          </p>
        </Card>

        <Card className="p-5 mt-6 bg-card/40 backdrop-blur border-border">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              AI Stats
            </h2>
            <Button variant="ghost" size="sm" onClick={reset} disabled={!total}>
              Reset
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <div className="text-muted-foreground">Rounds played</div>
              <div className="text-2xl font-semibold">{total}</div>
            </div>
            <div>
              <div className="text-muted-foreground">AI win rate</div>
              <div className="text-2xl font-semibold">{aiWinRate}%</div>
            </div>
          </div>
          <p className="mt-4 text-xs text-muted-foreground leading-relaxed">
            The AI uses a Markov chain on your last two moves to predict the next one, then plays
            the counter. The more you play, the smarter it gets.
          </p>
        </Card>
      </div>
    </div>
  );
}

function ScoreCard({ label, value, accent }: { label: string; value: number; accent?: "primary" | "accent" }) {
  const color =
    accent === "primary" ? "text-primary" : accent === "accent" ? "text-accent" : "text-foreground";
  return (
    <Card className="p-4 text-center bg-card/60 backdrop-blur border-border">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`text-3xl font-bold mt-1 ${color}`}>{value}</div>
    </Card>
  );
}