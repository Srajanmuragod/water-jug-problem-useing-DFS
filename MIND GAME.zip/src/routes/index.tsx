import { createFileRoute } from "@tanstack/react-router";
import { RPSGame } from "@/components/RPSGame";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mind Reader — AI Rock Paper Scissors" },
      { name: "description", content: "Play rock paper scissors against an AI that learns your patterns and predicts your next move." },
      { property: "og:title", content: "Mind Reader — AI Rock Paper Scissors" },
      { property: "og:description", content: "Can you outsmart an AI that learns your patterns?" },
    ],
  }),
  component: Index,
});

function Index() {
  return <RPSGame />;
}
